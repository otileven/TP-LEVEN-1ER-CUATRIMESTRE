package com.example.musicapp.SegundaPantalla

import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.Adapter
import com.example.musicapp.Adapter.songAdapter
import com.example.musicapp.Class.SongClass
import com.example.musicapp.R
import com.example.musicapp.Repository.MusicRepository


@Suppress("UNUSED_ANONYMOUS_PARAMETER")
class RecycleView : Fragment() {

    companion object {
        fun newInstance() = RecycleView()
    }
    private lateinit var viewModel:RecycleViewViewModel
    private lateinit var v : View
    private lateinit var recSong : RecyclerView
    private var info = MusicRepository()
    private lateinit var musicList: MutableList<SongClass>


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        v = inflater.inflate(R.layout.fragment_recycle_view, container, false)
        recSong = v.findViewById(R.id.recSongs)

        return v
    }
    override fun onStart() {
        super.onStart()


            // Verificar si la propiedad recSongs ha sido inicializada antes de utilizarla
          if (!::recSong.isInitialized) {
             return
          }

        recSong.setHasFixedSize(true)

        recSong.layoutManager  = LinearLayoutManager(context)

      recSong.adapter = songAdapter(info.getSongs()){  SongClass->
          viewModel.songName = SongClass.title
          viewModel.songBand = SongClass.band
          view?.findNavController()?.navigate(R.id.action_recycleView_to_info2)

      }





     }


    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProvider(requireActivity()).get(RecycleViewViewModel::class.java)
        // TODO: Use the ViewModel
    }

}