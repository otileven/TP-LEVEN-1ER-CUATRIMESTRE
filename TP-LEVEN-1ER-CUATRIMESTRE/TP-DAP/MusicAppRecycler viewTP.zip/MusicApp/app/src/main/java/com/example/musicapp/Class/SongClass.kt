package com.example.musicapp.Class

class SongClass(

    var title:String,
    var year:String,
    var band:String

) {
}