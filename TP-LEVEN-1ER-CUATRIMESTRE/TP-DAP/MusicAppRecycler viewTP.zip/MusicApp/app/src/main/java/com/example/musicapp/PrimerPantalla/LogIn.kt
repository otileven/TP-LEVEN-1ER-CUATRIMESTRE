package com.example.musicapp.PrimerPantalla

import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import androidx.navigation.findNavController
import com.example.musicapp.Class.UserClass
import com.example.musicapp.R
import com.google.android.material.snackbar.Snackbar

class LogIn : Fragment() {

    companion object {
        fun newInstance() = LogIn()
    }

    private lateinit var viewModel: LogInViewModel
    private lateinit var v : View
    private lateinit var inputUser: EditText
    private lateinit var inputPswr: EditText
    private lateinit var registerbtn: Button
    private lateinit var loginbtn: Button
     var contador: Int = 0

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        v = inflater.inflate(R.layout.fragment_log_in,container,false)
        inputUser = v.findViewById(R.id.editUser)
        inputPswr = v.findViewById(R.id.editPSWR)
        registerbtn = v.findViewById(R.id.btnREGISTER)
        loginbtn = v.findViewById(R.id.btnLOGIN)
        return v
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProvider(requireActivity()).get(LogInViewModel::class.java)
        viewModel.users.add(UserClass("Liam","1234"))
        viewModel.users.add(UserClass("Ari","5678"))
        viewModel.users.add(UserClass("Octavio","qwerty"))
        viewModel.users.add(UserClass("Maximo","asdfg"))



        registerbtn.setOnClickListener(){
            v?.findNavController()?.navigate(R.id.action_logIn_to_register)

        }
        loginbtn.setOnClickListener {
            val userLog: String = inputUser.text.toString()
            val pswrLog: String = inputPswr.text.toString()

            viewModel.users.find { u -> u.name == userLog }

            if (userLog.isEmpty() || pswrLog.isEmpty()) {
                Snackbar.make(v, "ingrese nombre y usuario", Snackbar.LENGTH_SHORT)
                    .show()
            }
            else{
            for (i in 0 until viewModel.users.size){

                if (userLog == viewModel.users[i].name){
                    if (pswrLog == viewModel.users[i].pswr){

                        Snackbar.make(v, "logeandose", Snackbar.LENGTH_SHORT)
                            .show()
                       v?.findNavController()?.navigate(R.id.action_logIn_to_recycleView)

                    }
                }
                else{
                    if (i == viewModel.users.size-1  ){
                        Snackbar.make(v, "sesion iniciada", Snackbar.LENGTH_SHORT)
                            .show()
                        v?.findNavController()?.navigate(R.id.action_logIn_to_recycleView)
                    }

                }

            }
            }


        }

    }

}