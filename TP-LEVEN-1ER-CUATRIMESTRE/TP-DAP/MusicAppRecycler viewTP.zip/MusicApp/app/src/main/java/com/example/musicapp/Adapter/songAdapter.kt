package com.example.musicapp.Adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.example.musicapp.Class.SongClass
import com.example.musicapp.R

class songAdapter(
    var songlist:MutableList<SongClass>,
    var onClick:(SongClass)-> Unit
)  :RecyclerView.Adapter<songAdapter.songHolder>() {

    class songHolder (v: View) : RecyclerView.ViewHolder(v) {
        private var view: View
        init {
            this.view = v
        }

        fun setTitle (title : String){
            var txtTitle : TextView = view.findViewById(R.id.txtTitleSong)
            txtTitle.text = title
        }

        fun getCardView () : CardView {
            return view.findViewById(/* id = */ R.id.cardSong)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): songHolder {
        val view =  LayoutInflater.from(parent.context).inflate(R.layout.itemsong,parent,false)
        return (songHolder(view))
    }

    override fun onBindViewHolder(holder: songHolder, position:Int) {
        holder.setTitle(songlist[position].title)
        holder.getCardView().setOnClickListener {
            onClick(songlist[position])
        }
    }

    override fun getItemCount(): Int {
        return songlist.size
    }

}
